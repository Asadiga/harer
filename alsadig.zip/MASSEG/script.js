function sendMessage() {
    const messageInput = document.getElementById('messageInput');
    const messageText = messageInput.value.trim();

    if (messageText === "") {
        return; // لا نرسل رسالة فارغة
    }

    const chatBox = document.getElementById('chatBox');

    // إنشاء عنصر جديد لعرض الرسالة
    const newMessage = document.createElement('div');
    newMessage.classList.add('message');
    newMessage.textContent = messageText;

    // إضافة الرسالة إلى مربع الدردشة
    chatBox.appendChild(newMessage);

    // تمرير الرسائل إلى الأسفل بعد إضافة رسالة جديدة
    chatBox.scrollTop = chatBox.scrollHeight;

    // مسح حقل الإدخال بعد إرسال الرسالة
    messageInput.value = "";
}
// إعداد Firebase
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_AUTH_DOMAIN",
    databaseURL: "YOUR_DATABASE_URL",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID"
};

// تهيئة Firebase
const app = firebase.initializeApp(firebaseConfig);
const database = firebase.database(app);

// إرسال الرسالة إلى Firebase
function sendMessage() {
    const messageInput = document.getElementById('messageInput');
    const messageText = messageInput.value.trim();

    if (messageText === "") {
        return;
    }

    // إضافة الرسالة إلى قاعدة البيانات
    firebase.database().ref('messages').push({
        message: messageText,
        timestamp: Date.now()
    });

    // مسح حقل الإدخال
    messageInput.value = "";
}

// عرض الرسائل من Firebase
firebase.database().ref('messages').on('child_added', function(snapshot) {
    const message = snapshot.val();
    const messageText = message.message;

    const chatBox = document.getElementById('chatBox');

    // إنشاء عنصر جديد لعرض الرسالة
    const newMessage = document.createElement('div');
    newMessage.classList.add('message');
    newMessage.textContent = messageText;

    // إضافة الرسالة إلى مربع الدردشة
    chatBox.appendChild(newMessage);

    // تمرير الرسائل إلى الأسفل بعد إضافة رسالة جديدة
    chatBox.scrollTop = chatBox.scrollHeight;
});
// إعداد Firebase
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_AUTH_DOMAIN",
    databaseURL: "YOUR_DATABASE_URL",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID"
};

// تهيئة Firebase
const app = firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const database = firebase.database(app);

// تسجيل الدخول باستخدام جوجل
function loginWithGoogle() {
    const provider = new firebase.auth.GoogleAuthProvider();
    auth.signInWithPopup(provider)
        .then((result) => {
            const user = result.user;
            // عند النجاح، عرض واجهة التطبيق
            document.getElementById('loginScreen').style.display = 'none';
            document.getElementById('appScreen').style.display = 'block';
            // عرض اسم وصورة المستخدم
            document.getElementById('userName').textContent = user.displayName;
            document.getElementById('userProfileImage').src = user.photoURL;
        })
        .catch((error) => {
            console.log(error.message);
        });
}

// تسجيل الخروج
function logout() {
    auth.signOut().then(() => {
        document.getElementById('loginScreen').style.display = 'block';
        document.getElementById('appScreen').style.display = 'none';
    });
}

// إرسال الرسالة
function sendMessage() {
    const messageInput = document.getElementById('messageInput');
    const messageText = messageInput.value.trim();

    if (messageText === "") {
        return;
    }

    // إضافة الرسالة إلى قاعدة البيانات
    firebase.database().ref('messages').push({
        message: messageText,
        timestamp: Date.now(),
        userName: auth.currentUser.displayName,
        userPhoto: auth.currentUser.photoURL
    });

    // مسح حقل الإدخال
    messageInput.value = "";
}

// عرض الرسائل من Firebase
firebase.database().ref('messages').on('child_added', function(snapshot) {
    const message = snapshot.val();
    const messageText = message.message;
    const userName = message.userName;
    const userPhoto = message.userPhoto;

    const chatBox = document.getElementById('chatBox');

    // إنشاء عنصر جديد لعرض الرسالة
    const newMessage = document.createElement('div');
    newMessage.classList.add('message');
    newMessage.innerHTML = `
        <img src="${userPhoto}" alt="User" width="30" height="30">
        <strong>${userName}:</strong>
        <p>${messageText}</p>
    `;

    // إضافة الرسالة إلى مربع الدردشة
    chatBox.appendChild(newMessage);

    // تمرير الرسائل إلى الأسفل بعد إضافة رسالة جديدة
    chatBox.scrollTop = chatBox.scrollHeight;
});
// إعداد Firebase
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_AUTH_DOMAIN",
    databaseURL: "YOUR_DATABASE_URL",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID"
};

// تهيئة Firebase
const app = firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const database = firebase.database(app);

// تسجيل الدخول باستخدام جوجل
function loginWithGoogle() {
    const provider = new firebase.auth.GoogleAuthProvider();
    auth.signInWithPopup(provider)
        .then((result) => {
            const user = result.user;
            // عند النجاح، عرض واجهة التطبيق
            document.getElementById('loginScreen').style.display = 'none';
            document.getElementById('appScreen').style.display = 'block';
            // عرض اسم وصورة المستخدم
            document.getElementById('userName').textContent = user.displayName;
            document.getElementById('userProfileImage').src = user.photoURL;
        })
        .catch((error) => {
            console.log(error.message);
        });
}

// تسجيل الخروج
function logout() {
    auth.signOut().then(() => {
        document.getElementById('loginScreen').style.display = 'block';
        document.getElementById('appScreen').style.display = 'none';
    });
}

// إرسال الرسالة
function sendMessage() {
    const messageInput = document.getElementById('messageInput');
    const messageText = messageInput.value.trim();

    if (messageText === "") {
        return;
    }

    // إضافة الرسالة إلى قاعدة البيانات
    firebase.database().ref('messages').push({
        message: messageText,
        timestamp: Date.now(),
        userName: auth.currentUser.displayName,
        userPhoto: auth.currentUser.photoURL
    });

    // مسح حقل الإدخال
    messageInput.value = "";
}

// عرض الرسائل من Firebase
firebase.database().ref('messages').on('child_added', function(snapshot) {
    const message = snapshot.val();
    const messageText = message.message;
    const userName = message.userName;
    const userPhoto = message.userPhoto;

    const chatBox = document.getElementById('chatBox');

    // إنشاء عنصر جديد لعرض الرسالة
    const newMessage = document.createElement('div');
    newMessage.classList.add('message');
    newMessage.innerHTML = `
        <img src="${userPhoto}" alt="User" width="30" height="30">
        <strong>${userName}:</strong>
        <p>${messageText}</p>
    `;

    // إضافة الرسالة إلى مربع الدردشة
    chatBox.appendChild(newMessage);

    // تمرير الرسائل إلى الأسفل بعد إضافة رسالة جديدة
    chatBox.scrollTop = chatBox.scrollHeight;
}

// وظيفة لفتح نافذة معلومات المبرمجين
function showDeveloperInfo() {
    document.getElementById('developerInfoModal').style.display = 'block';
}

// وظيفة لإغلاق نافذة معلومات المبرمجين
function closeDeveloperInfo() {
    document.getElementById('developerInfoModal').style.display = 'none';
}

// إغلاق النافذة عند الضغط على أي مكان خارج النافذة
window.onclick = function(event) {
    if (event.target == document.getElementById('developerInfoModal')) {
        closeDeveloperInfo();
    }
}
